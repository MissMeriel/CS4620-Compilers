package symtable;

public class Signature{
	LinkedList<Formal> formals;
	LinkedList<VarDecl> varDecls;
	
	
}
