/**
 * PA5obj.java
 * 
 * call setP method
 * setP: local object
 * WB, 4/12
 */

import meggy.Meggy;

class PA5Tones {

    public static void main(String[] whatever){
		Meggy.toneStart(Meggy.Tone.C3, 100);
		Meggy.delay(10);
		Meggy.toneStart(Meggy.Tone.Cs3, 100);
		Meggy.delay(10);
		Meggy.toneStart(Meggy.Tone.D3, 100);
		Meggy.delay(10);
		Meggy.toneStart(Meggy.Tone.Ds3, 100);
		Meggy.delay(10);
		Meggy.toneStart(Meggy.Tone.E3, 100);
		Meggy.delay(10);
		Meggy.toneStart(Meggy.Tone.F3, 100);
		Meggy.delay(10);
		Meggy.toneStart(Meggy.Tone.Fs3, 100);
		Meggy.delay(10);
		Meggy.toneStart(Meggy.Tone.G3, 100);
		Meggy.delay(10);
		Meggy.toneStart(Meggy.Tone.Gs3, 100);
		Meggy.delay(10);
		Meggy.toneStart(Meggy.Tone.A3, 100);
		Meggy.delay(10);
		Meggy.toneStart(Meggy.Tone.As3, 100);
		Meggy.delay(10);
		Meggy.toneStart(Meggy.Tone.B3, 100);
		Meggy.delay(10);
    }
}

