/**
 * PA5obj.java
 * 
 * call setP method
 * setP: local object
 * WB, 4/12
 */

import meggy.Meggy;

class PA5obj {

    public static void main(String[] whatever){
		Ind oy;
        oy = new Ind(); 
    }
}

class Ind{
    byte _i;
    public void put(byte i){
	_i = i;
    }
    public byte get(){
	return _i;
    }
}
